package com.qq.fragment;

import android.support.v4.app.Fragment;

public class WIFIFragment extends Fragment {

}
