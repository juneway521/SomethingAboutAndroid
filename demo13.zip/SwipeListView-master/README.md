SwipeListView
=============

android swipe listView like weChat 

一个仿微信对话列表中可以向左滑动ListView的Item的控件。

效果如下图：
![效果图](images/2013-12-18-164219.png)
