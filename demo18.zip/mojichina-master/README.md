模仿墨迹天气3.0引导界面


![](https://raw.githubusercontent.com/xyzhang/mojichina/master/screen/moji2.gif)


屏幕录制使用的licecap
http://www.cockos.com/licecap/


README.md编辑参考
http://www.tuicool.com/articles/zIJrEjn




  @author 张兴业
  
  http://blog.csdn.net/xyz_lmn
  
  我的新浪微博：[@张兴业TBOW](http://weibo.com/xyzlmn)

